from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'
    verbose_name = 'SUTRA Core'

    def ready(self):
        # Import signals if any are defined
        pass
